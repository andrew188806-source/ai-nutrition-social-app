import subprocess,shutil,json
from pathlib import Path
root=Path('/mnt/d/haocu app/ai-nutrition-social-mvp');base=Path('/tmp/pc2-remediation');inv=json.loads((root/'scripts/pc2-remediation-inventory.json').read_text())['paths'];ref='d38e66ad8c8e10d69977873cd815f71aec374cdc'
for name in ['integrity-candidate','integrity-replica-1','integrity-replica-2']:
 p=base/name
 if p.exists():shutil.rmtree(p)
 p.mkdir();subprocess.run(['tar','-xf',str(base/'immutable-implementation.tar'),'-C',str(p)],check=True);subprocess.run(['git','init','-q','--initial-branch=main'],cwd=p,check=True);(p/'.git/objects/info/alternates').write_text(str(base/'git-object-cache')+'\n')
 for args in [['update-ref','refs/heads/main',ref],['update-ref','refs/remotes/origin/main','30268ee4de59a8d8855c1dcaa01795d2f1ce33b1'],['read-tree',ref],['config','core.filemode','false']]:subprocess.run(['git',*args],cwd=p,check=True)
 for dep in ['node_modules','apps/mobile/node_modules','apps/admin-web/node_modules','apps/restaurant-web/node_modules']:
  if (root/dep).exists():(p/dep).symlink_to(root/dep,target_is_directory=True)
 for f in inv:(p/f).parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/f,p/f)
print({'replicas':3,'inventory':len(inv)})
