import json,hashlib,zipfile
from pathlib import Path
root=Path('/mnt/d/haocu app/ai-nutrition-social-mvp');base=Path('/tmp/pc2-remediation');target=root/'docs/planning/pc2-onboarding-preparation'
report=json.loads((target/'pc2-remediation-differential.json').read_text())
assert report['suites']==478 and report['NEW_REGRESSION']==0 and report['allFailureVectorsVerified']
logs=base/'final-complete-differential.json.logs';extra=['final60-recognition-negatives.log','final60-pc2-mutations.log','final60-gqa6r-mutations.json','sealed-gqa6r-record-controls.json','typechecks.json','pc2-smoke.log','reuse-provenance.json','frozen-boundaries.json','additional-scope-findings.json','partial-sweep-disposition.json','lineage-partial-disposition.json','git-object-cache-provenance.json','baseline-cause-analysis.json','recognition-audit.json','final-prebinding-checks.json','guard-scope-probe.json','gqa5-composed-path-controls.json','additional-phase2y-scope-findings.json','additional-restaurant-scope-findings.json','additional-phase2y-db-scope-finding.json','root-gqa-concurrent-diagnostic-disposition.json','final-scope-diagnostic-disposition.json','restaurant-lineage-diagnostic-disposition.json','reusable-baseline.json.baseline.partial.json','complete-differential.json.baseline.partial.json','sealed-differential.json.baseline.partial.json','negative-object-cache-provenance.json','postcommit-fixture-diagnostic-disposition.json','assertion-restoration-diagnostic-disposition.json','cipher-padding-current.json','cipher-padding-baseline.json','cipher-padding-proof.mjs','crypto-timeout-diagnostic-disposition.json','crypto-timeout-diagnostic.json','superseded-tree-cleanup.json','final-bound-pc2-guard.log','final-bound-pc2-smoke.log','final-bound-guard-probe.json','final-bound-guard-probe.stdout']
archive=target/'pc2-remediation-raw-output.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 seen=set()
 for r in report['baselineResults']+report['candidateResults']:
  name=r['rawOutput']['entry'];b=(logs/name).read_bytes();assert hashlib.sha256(b).hexdigest()==r['rawOutput']['sha256'];assert name not in seen;seen.add(name);z.writestr(name,b)
 for f in extra:
  p=base/f
  if p.exists():z.writestr('supplemental/'+f,p.read_bytes())
 for proof in base.glob('final-bound-probe-*.json'):z.writestr('supplemental/affected-guards/'+proof.name,proof.read_bytes())
 for diagnostic in ['candidate-test_taste-similarity-ts6-mutations.json','candidate-test_social-candidate-sr2d-smoke.json']:
  p=base/'crypto-timeout-diagnostic.json.logs'/diagnostic
  if p.exists():z.writestr('supplemental/diagnostics/'+diagnostic,p.read_bytes())
 z.writestr('supplemental/package-evidence.py',Path(__file__).read_bytes())
 z.writestr('supplemental/rebuild-final-trees.py',(base/'rebuild-final-trees.py').read_bytes())
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 secret=[]
 import re
 pattern=re.compile(rb'\b(?:sb_secret_|sb_publishable_)[A-Za-z0-9_-]+|\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b|-----BEGIN [A-Z ]*PRIVATE KEY-----')
 for f in z.namelist():
  if pattern.search(z.read(f)):secret.append(f)
 assert not secret,secret
 print(json.dumps({'rawSuiteEntries':len(seen),'totalEntries':len(z.namelist()),'readable':True,'secretFindings':secret,'zipBytes':archive.stat().st_size}))
