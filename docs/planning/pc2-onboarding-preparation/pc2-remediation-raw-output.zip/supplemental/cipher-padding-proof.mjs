#!/usr/bin/env node
// SR-2D local smoke. Pure and local: no network, no database, no credentials, no deployment.
// The real SR-1A pair composition, SR-2A ranking, SR-2B exposure, SR-2C projection and the real
// AES-256-GCM reference primitive all execute; only the SQL transport and the authenticated
// Supabase client are substituted, and the repository bytes are never modified.
import fs from "node:fs";
import path from "node:path";
import { createRequire } from "node:module";

const root = process.cwd();
const require_ = createRequire(import.meta.url);
const ts = require_("typescript");

const checks = [];
const failures = [];
function check(name, condition, detail) {
  const result = Object.freeze({ name, pass: Boolean(condition), ...(detail === undefined ? {} : { detail }) });
  checks.push(result);
  if (!result.pass) failures.push(result);
  console.log(`${result.pass ? "PASS" : "FAIL"} ${name}`);
}

// --- module loader --------------------------------------------------------------------------
const npmStubs = new Map([
  ["npm:@supabase/supabase-js@2", { createClient: () => ({}) }],
  ["npm:postgres@3.4.7", { default: () => ({}) }]
]);
globalThis.Deno = globalThis.Deno ?? { env: { get: () => undefined }, serve: () => {} };

const cache = new Map();
const resolveFile = (candidate) =>
  [candidate, `${candidate}.ts`, `${candidate}.mjs`, path.join(candidate, "index.ts")]
    .find((entry) => fs.existsSync(entry) && fs.statSync(entry).isFile());
function load(absolute) {
  if (cache.has(absolute)) return cache.get(absolute).exports;
  const raw = fs.readFileSync(absolute, "utf8");
  // TypeScript forces ESM output for a .mjs filename regardless of the module setting, so the
  // generated Taste runtime is transpiled under a .js name to obtain CommonJS.
  const { outputText } = ts.transpileModule(raw, {
    compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022, allowJs: true },
    fileName: absolute.endsWith(".mjs") ? `${absolute.slice(0, -4)}.js` : absolute
  });
  const module = { exports: {} };
  cache.set(absolute, module);
  const localRequire = (specifier) => {
    if (npmStubs.has(specifier)) return npmStubs.get(specifier);
    if (!specifier.startsWith(".")) return require_(specifier);
    const resolved = resolveFile(path.resolve(path.dirname(absolute), specifier));
    if (!resolved) throw new Error(`unresolved import: ${specifier}`);
    return load(resolved);
  };
  new Function("require", "module", "exports", outputText)(localRequire, module, module.exports);
  return module.exports;
}
const fromRoot = (relative) => load(path.join(root, relative));

const api = fromRoot("supabase/functions/_shared/social-candidate-api/index.ts");
const ref = fromRoot("supabase/functions/_shared/social-candidate-ref/index.ts");
const handlerModule = fromRoot("supabase/functions/social-candidate-list/handler.ts");

// --- fixtures --------------------------------------------------------------------------------
const ACTOR = "00000000-0000-4000-8000-0000000000aa";
const OTHER_ACTOR = "00000000-0000-4000-8000-0000000000bb";
const candidateId = (index) => `00000000-0000-4000-8000-${String(index).padStart(12, "0")}`;
const CANDIDATES = Array.from({ length: 12 }, (_, index) => candidateId(index + 1));
const EMPTY_SOURCES = Object.freeze({
  dietary_restrictions: { rows: [] },
  favorite_menu_items: { rows: [] },
  favorite_restaurants: { rows: [] },
  meal_record_items: { rows: [] },
  meal_records: { rows: [] },
  nutrition_goals: { rows: [] },
  taste_profiles: { rows: [] }
});
const TEST_KEY = Buffer.alloc(32, 7).toString("base64");
const cipher = ref.createSocialCandidateRefCipher(ref.decodeSocialCandidateRefKey(TEST_KEY));
const INSTANT = new Date("2026-08-16T12:00:00.000Z");


let paddingExample=null;let byteMutationsRejected=0;for(let i=0;i<128;i++){const original=await cipher.seal(ACTOR,CANDIDATES[0],INSTANT),body=original.slice("scr1.".length),bytes=Buffer.from(body,"base64url");const flipped=body.slice(0,-1)+(body.at(-1)==="A"?"B":"A");if(!paddingExample&&body.at(-1)==="A"){const sameBytes=bytes.equals(Buffer.from(flipped,"base64url"));let admitted=false;try{await cipher.open(ACTOR,"scr1."+flipped,INSTANT);admitted=true;}catch{}paddingExample={changedEncodedText:body!==flipped,decodedEncryptedBodyUnchanged:sameBytes,authenticatedUnchangedBody:admitted};}const mutated=Buffer.from(bytes);mutated[mutated.length-1]^=1;try{await cipher.open(ACTOR,"scr1."+mutated.toString("base64url"),INSTANT);}catch{byteMutationsRejected++;}}console.log(JSON.stringify({kind:"REAL_AES_GCM_MUTATION_PREMISE_PROOF",paddingExample,realByteMutations:128,realByteMutationsRejected:byteMutationsRejected,networkUsed:false,databaseUsed:false}));if(!paddingExample?.decodedEncryptedBodyUnchanged||!paddingExample?.authenticatedUnchangedBody||byteMutationsRejected!==128)process.exitCode=1;
