# Investor Memo Draft

> Repository Status: Haocu OS Master Repository v2.0 Alpha 6.
> Scope: Business, Legal/IP, Finance, Pitch, Investor Materials, External Artifacts, and final Repository Packaging.
> Audience: founder, CTO, engineers, designers, legal counsel, accountants, advisors, crowdfunding partners, and investors.

## Cross-Repository Boundaries

- **Taiwan-first MVP**: consumer mobile app, AI meal analysis, meal records, restaurant discovery, Meal Buddy cards, chat/invitations, group tables, premium limits, restaurant/admin tools, and clean demo readiness are the baseline.
- **Database-first AI**: verified restaurant/menu/nutrition data is preferred before free-form AI inference; AI output must expose uncertainty and correction paths.
- **Nutrition boundary**: Haocu provides food information and meal guidance, not medical diagnosis, prescription dieting, disease treatment, or guaranteed health outcomes.
- **Social safety boundary**: Meal Buddy and group dining features must protect identity, consent, harassment prevention, meeting safety, moderation, and abuse reporting.
- **Professional review boundary**: legal, patent, trademark, securities, accounting, tax, nutrition claims, and valuation matters require qualified external review before external publication or execution.
- **Clean UI principle**: Haocu should remain tidy, readable, spacious, demo-friendly, and free from duplicate controls.


## Objective

Create a concise investor memo draft.

## Operating Principles

- Memo must match deck.
- State current status and next milestone.
- Use assumptions not fake certainty.
- Use-of-funds is milestone-based.

## Requirements

| Area | Decision / Requirement | Review / Acceptance |
|---|---|---|
| Summary | Taiwan-first AI food recommendation with optional social dining. | Clear. |
| Problem/solution | Fragmented daily food decisions; corrected memory loop. | Clear. |
| Business/GTM | Premium, restaurant, crowdfunding; demo→pilot→campaign→beta. | Staged. |
| Risks/ask | Product, AI, restaurant, social, monetization, legal/IP; ask after review. | Honest. |


## Review Checklist

- [ ] Memo aligns with FAQ/deck.
- [ ] No unsupported numbers.
- [ ] Review notes included.
- [ ] Ask is clear.

## Implementation / Action Backlog

| Priority | Task | Acceptance Criteria |
|---|---|---|
| P0 | Finalize memo draft | Attach to data room. |
| P1 | Update with metrics | After pilot. |


## Draft Summary

Haocu is a Taiwan-first AI food recommendation and optional social dining platform for outside eaters. It starts with AI meal analysis and user correction, then uses corrected meal records to build private taste/nutrition memory and recommend what to eat next. Users who want company can create Meal Buddy cards or group tables based on food intent. Restaurants can provide structured menu data to improve recommendation accuracy and discovery.


## Dependencies

- 01_Product for product boundaries and MVP scope.
- 02_PRD for feature requirements and acceptance criteria.
- 03_AI and 04_Data for AI/data boundaries.
- 14_Compliance and 17_Legal_IP for public claims, privacy, and professional review.
- 18_Finance for cost, runway, pricing, and fundraising assumptions.
